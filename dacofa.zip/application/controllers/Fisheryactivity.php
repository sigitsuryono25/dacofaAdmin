<?php

/**
 * include file Basecontroller
 * so we can extends into it.
 *  
 * */
include_once(dirname(__FILE__) . "/Basecontroller.php");

class Fisheryactivity extends Basecontroller
{
	function index()
	{
		$data['fishery'] = $this->db->query("SELECT * FROM tb_lokasi INNER JOIN tb_user ON tb_lokasi.userid=tb_user.userid")->result();
		$this->load->view('headfoot/header');
		$this->load->view('fishery/daftar-fishery', $data);
		$this->load->view('headfoot/footer');
	}

	function hasilTangkapan($idLokasi)
	{
		$data['fishery'] = $this->db->query("SELECT * FROM tb_lokasi INNER JOIN tb_user ON tb_lokasi.userid=tb_user.userid WHERE id IN ('$idLokasi')")->row();
		$data['hasil'] = $this->db->query("SELECT * FROM tb_detail_tangkapan WHERE id_header IN ('$idLokasi')")->result();
		$this->load->view('headfoot/header');
		$this->load->view('fishery/detail-tangkapan', $data);
		$this->load->view('headfoot/footer');
	}
}
