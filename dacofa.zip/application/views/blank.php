<div class="container-fluid">
	<div class="card">
		<div class="card-header">
			<h5 class="card-title">
				Title here
			</h5>
		</div>
		<div class="card-body">
			content goes here
		</div>
	</div>
</div>
